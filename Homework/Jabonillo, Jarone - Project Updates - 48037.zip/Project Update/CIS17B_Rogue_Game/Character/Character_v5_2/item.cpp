#include "item.h"

Item::Item()
{
    xPos = 0;
    yPos = 0;
    iDamage = 0;
    iArmor = 0;
    iCrit = 0;
    iSpd = 0;
    itemID = 6;     //Item ID 6 reserved for empty placeholder items
    iName = "none";
}
