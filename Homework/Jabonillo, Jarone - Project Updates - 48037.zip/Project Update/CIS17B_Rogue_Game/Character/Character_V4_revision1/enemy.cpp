#include "enemy.h"

Enemy::Enemy()
{

}
