/*
revision 1 notes:

added basic levelling system in player.h
and player.cpp.

Eliminated superfluous
addExp() function in player.h

added levelling declarations to player constructor

Curt Burdette 9/29/16 8:55a

fixed bad code in Player::lvlUp()

Curt Burdette 9/29/16 10:07p
*/

#include <QApplication>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    //QApplication a(argc, argv);
    cout <<"We're good!\n";

    return 0;
    //return a.exec();
}
