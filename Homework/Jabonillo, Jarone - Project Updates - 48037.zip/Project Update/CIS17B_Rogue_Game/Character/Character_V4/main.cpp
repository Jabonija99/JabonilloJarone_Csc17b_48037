#include <QApplication>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    //QApplication a(argc, argv);
    cout <<"We're good!\n";

    return 0;
    //return a.exec();
}

