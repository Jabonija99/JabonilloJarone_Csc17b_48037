#include "roomwidget.h"

RoomWidget::RoomWidget(QWidget *parent) : QGraphicsScene(parent)
{
//    rows = 9;
//    cols = 15;

//    newRoom = new QWidget;
//    newRoom->setFixedSize(960,540);
//    //create the tiles
//    Tile *tileSet;
//    tileSet = new Tile[144];

//    //iterate through array of tiles
//    for(int i=0;i<rows;i++){
//        for(int j=0;j<cols;j++){
//            //set map array values
//            tileSet[(i*cols)+j].setVal(newRoom.getRoom(4,4)->getRoomVal(i,j));
////            tileSet[(i*COLS)+j].setVal(samp[i][j]);
//            //set pixmaps
//            tileSet[(i*cols)+j].design(j,i);
//            //position tiles
//            tileSet[(i*cols)+j].move(j,i);
//            //add to scene
//            newRoom->addItem(tileSet+((i*cols)+j));
//        }
//    }

}
